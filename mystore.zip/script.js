document.addEventListener("DOMContentLoaded", function() {
    console.log("المتجر جاهز!");
});